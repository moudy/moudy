(function () {
  var de = document.documentElement;
  de.className = de.className+' ready';
})();
