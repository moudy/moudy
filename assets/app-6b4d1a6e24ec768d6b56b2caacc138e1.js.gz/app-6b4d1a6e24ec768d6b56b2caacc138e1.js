(function () {
  setTimeout(function () {
  var de = document.documentElement;
  de.className = de.className+' ready';
  },10);
})();
